
let type = document.getElementById('pc');
previous_button.addEventListener('click', change_page);

function change_page(){
    document.getElementById("pc").src =  "resultats.html";


}