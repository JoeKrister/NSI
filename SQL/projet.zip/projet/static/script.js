var btn1 = document.querySelector(".btn1");
btn1.addEventListener("click", inversement);

function inversement1(){
	document.getElementById("desc").click()
	document.location.href="pieceothequeD"
}

function inversement2(){
	document.getElementById("asc").click()
	document.location.href="pieceotheque"
}
